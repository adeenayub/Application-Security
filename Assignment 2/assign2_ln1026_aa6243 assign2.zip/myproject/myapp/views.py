from django.http import HttpResponse
from django.shortcuts import render
from django.contrib.auth.forms import UserCreationForm
from django.urls import reverse_lazy
from django.views import generic
import os

import string
from spellchecker import SpellChecker
l = []


def upload(request):
  if request.method == 'POST':
    ans = handle_uploaded_file(request.FILES['file'], str(request.FILES['file']))
    return HttpResponse(ans)
  return HttpResponse("Failed")


def handle_uploaded_file(file, filename):
  if not os.path.exists('upload/'):
    os.mkdir('upload/')

  with open('upload/' + filename, 'wb+') as dest:
    for chunk in file.chunks():
      dest.write(chunk)
    dest.close()

  with open('upload/' + filename, 'r+') as f:
    for line in f:
      for word in line.split():
        temp = word.strip(string.punctuation)
        l.append(temp.lower())
  f.close()
  spell = SpellChecker()
  outp = ''
  misspelled = spell.unknown(l)  # filters the words that are not found in the dictionary
  for word in misspelled:
         # Get the one `most likely` answer
    print(word + ' is wrongly spelt')
    print(spell.correction(word))

    # Get a list of `likely` options
    print(spell.candidates(word))
    outp = outp + word + ' is not correctly spelt' + '        '
  return outp
  # return 'all correct'


# Create your views here.
class SignUp(generic.CreateView):
  form_class = UserCreationForm
  success_url = reverse_lazy('login')
  template_name = 'signup.html'
