import string
from spellchecker import SpellChecker
l = []
name = input('enter filename: ')  # enter the file you want to spell check
with open(name, 'r') as f:
    for line in f:
        for word in line.split():
            temp = word.strip(string.punctuation)  # removes any punctuations if exits
            l.append(temp.lower())  # the word is converted to lower case to compare spellings without any case sensitivity
f.close()
spell = SpellChecker()
#mylist = ['Lion','grou']
# find those words that may be misspelled
misspelled = spell.unknown(l)  # filters the words that are not found in the dictionary

for word in misspelled:
    # Get the one `most likely` answer
    print(word + ' is not correctly spelt')
    print(spell.correction(word))

    # Get a list of `likely` options
    print(spell.candidates(word))
