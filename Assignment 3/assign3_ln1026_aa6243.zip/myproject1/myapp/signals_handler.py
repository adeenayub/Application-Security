import logging
from django.contrib.auth.signals import user_logged_in, user_logged_out, user_login_failed
from django.dispatch import receiver
from django.dispatch import Signal
from django.db.models.signals import pre_save
from django.contrib.auth.models import User

log = logging.getLogger(__name__)

@receiver(user_logged_in)
def user_logged_in_callback(sender, request, user, **kwargs):    
    ip = request.META.get('REMOTE_ADDR')

    log.debug('{user} logged in via ip: {ip}'.format(
        user=user,
        ip=ip
    ))

@receiver(user_logged_out)
def user_logged_out_callback(sender, request, user, **kwargs): 
    ip = request.META.get('REMOTE_ADDR')

    log.debug('{user} logged out via ip: {ip}'.format(
        user=user,
        ip=ip
    ))

@receiver(user_login_failed)
def user_login_failed_callback(sender, credentials, **kwargs):
    log.warning('logout failed for: {credentials}'.format(
        credentials=credentials,
    ))


# signal sent when users successfully recover their passwords

#@receiver(password_changed)
#def user_recovers_pass(user):
 #  ip = requesr.META.get('REMOTE_ADDR')
  # log.debug('{user} changed password via ip: {ip}'.format(
   #    user = user, 
     #  ip = ip
  # ))
   
@receiver(pre_save, sender=User)
def user_updated(sender, **kwargs):
  user = kwargs.get('instance', None)
  if user:
    new_password = user.password
  try:
    old_password = User.objects.get(pk=user.pk).password
  except User.DoesNotExist:
    old_password = None
  if new_password != old_password:
    log.debug('%s changed password', user)
